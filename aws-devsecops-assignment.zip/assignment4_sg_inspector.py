# EC2 SG inspector script placeholder
