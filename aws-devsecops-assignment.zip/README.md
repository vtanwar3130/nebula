# AWS DevSecOps Automation Scripts

This repository contains five assignments automating security checks across AWS services using Python and Boto3.

## 📦 Setup Instructions
1. Install Python packages:
```bash
pip install boto3
```
2. Configure AWS CLI or set environment variables.
3. Run each script individually:
```bash
python assignment1_guardduty.py --region us-east-1
```

## 📁 Output Samples
- GuardDuty Findings: `/tmp/guardduty_findings.json`
- IAM Report: `output/iam_audit_report.json`
- S3 Security Check: `output/s3_audit_report.json`
- EC2 Risky SGs: `output/ec2_risky_groups.json`

## 🧠 Questions & Answers
1. **Python Scripting Skill:** 8/10  
2. **Boto3 Experience:** Yes, used for automating IAM, EC2, S3, and security audits.  
3. **API Validation:** Check response codes, handle exceptions, validate expected keys.  
4. **Exception Handling Example:**
```python
try:
    response = client.get_bucket_policy(Bucket='xyz')
except client.exceptions.NoSuchBucketPolicy:
    print("No policy found")
```
5. **AWS Security Automation:** Yes, automated GuardDuty setup, IAM audits, S3 checks, and more as shown above.

## 🔗 Submission
GitHub Repo: [GitHub Link Here]  
Email to: hr@nebulatechsolutions.com
